create table activitylevels
(
    activitylevel_id bigint unsigned auto_increment
        primary key,
    activitylevel    varchar(20) not null,
    description      varchar(70) null,
    constraint activitylevels_pk
        unique (activitylevel)
);

create table daysperweek
(
    daysperweek int not null
        primary key
);

create table equipmentlevels
(
    equipmentlevel_id bigint unsigned auto_increment
        primary key,
    equipmentlevel    varchar(30) not null,
    constraint equipmentlevels_pk
        unique (equipmentlevel)
);

create table exercisenames
(
    name varchar(50) not null
        primary key
);

create table experiencelevels
(
    experiencelevel_id bigint unsigned auto_increment
        primary key,
    experiencelevel    varchar(20) not null,
    constraint experiencelevels_pk
        unique (experiencelevel)
);

create table genders
(
    gender varchar(2) not null
        primary key
);

create table intensitylevels
(
    intensitylevel_id bigint unsigned auto_increment
        primary key,
    intensitylevel    varchar(20) not null,
    constraint intensitylevel_id
        unique (intensitylevel_id),
    constraint intensitylevels_pk2
        unique (intensitylevel)
);

create table musclegroups
(
    musclegroup varchar(10) not null
        primary key
);

create table overallgoals
(
    overgoal_id bigint unsigned auto_increment
        primary key,
    overallgoal varchar(30) null,
    constraint overallgoals_pk
        unique (overallgoal),
    constraint overgoal_id
        unique (overgoal_id)
);

create table goals
(
    user_id           bigint unsigned not null
        primary key,
    intensitylevel_id bigint unsigned null,
    overallgoal_id    bigint unsigned null,
    daysperweek       int             null,
    constraint goals_intensitylevels_intensitylevel_id_fk
        foreign key (intensitylevel_id) references intensitylevels (intensitylevel_id),
    constraint goals_overallgoals_overgoal_id_fk
        foreign key (overallgoal_id) references overallgoals (overgoal_id)
);

create index goals_daysperweek_daysperweek_fk
    on goals (daysperweek);

create table roles
(
    role_id bigint unsigned auto_increment
        primary key,
    role    varchar(10) null,
    constraint role_id
        unique (role_id),
    constraint roles_pk2
        unique (role)
);

create table settypes
(
    settype varchar(10) not null
        primary key
);

create table exercises
(
    exercise_id       bigint unsigned auto_increment
        primary key,
    equipmentlevel_id bigint unsigned null,
    musclegroup       varchar(10)     null,
    name              varchar(50)     null,
    settype           varchar(10)     null,
    targetmuscles     varchar(120)    null,
    videourl          varchar(200)    null,
    constraint exercises_equipmentlevels_equipmentlevel_id_fk
        foreign key (equipmentlevel_id) references equipmentlevels (equipmentlevel_id),
    constraint exercises_exercisenames_name_fk
        foreign key (name) references exercisenames (name),
    constraint exercises_musclegroups_musclegroup_fk
        foreign key (musclegroup) references musclegroups (musclegroup),
    constraint exercises_settypes_settype_fk
        foreign key (settype) references settypes (settype)
);

create table users
(
    user_id            bigint unsigned auto_increment
        primary key,
    username           varchar(60)     null,
    emailaddress       varchar(100)    null,
    password_hash      varchar(100)    null,
    firstname          varchar(60)     null,
    lastname           varchar(60)     null,
    age                int             null,
    weight             int             null,
    height             int             null,
    gender             varchar(2)      null,
    activitylevel_id   bigint unsigned null,
    experiencelevel_id bigint unsigned null,
    equipmentlevel_id  bigint unsigned null,
    role_id            bigint unsigned null,
    darkmode           tinyint         null,
    constraint users_pk
        unique (username),
    constraint users_pk2
        unique (emailaddress),
    constraint users_activitylevels_activitylevel_id_fk
        foreign key (activitylevel_id) references activitylevels (activitylevel_id),
    constraint users_equipmentlevels_equipmentlevel_id_fk
        foreign key (equipmentlevel_id) references equipmentlevels (equipmentlevel_id),
    constraint users_experiencelevels_experiencelevel_id_fk
        foreign key (experiencelevel_id) references experiencelevels (experiencelevel_id),
    constraint users_genders_gender_fk
        foreign key (gender) references genders (gender),
    constraint users_roles_role_id_fk
        foreign key (role_id) references roles (role_id)
);

create table users_exercises
(
    user_id        bigint unsigned not null,
    exercise_id    bigint unsigned not null,
    personalrecord int default 0   null,
    rating         int default 1   null,
    primary key (user_id, exercise_id),
    constraint users_exercises_users_user_id_fk
        foreign key (user_id) references users (user_id)
);

create table workoutplan
(
    user_id bigint unsigned not null,
    day     date            not null,
    primary key (user_id, day),
    constraint workoutplan_users_user_id_fk
        foreign key (user_id) references users (user_id)
);

create table workoutplan_exercises
(
    user_id     bigint unsigned         not null,
    day         date                    not null,
    exercise_id bigint unsigned         not null,
    sets        int         default 0   not null,
    reps        varchar(20) default '0' not null,
    rest        varchar(20) default '0' not null,
    weight      int         default 0   not null,
    rpe         int         default 0   not null,
    primary key (user_id, day, exercise_id),
    constraint workoutplan_exercises_exercises_exercise_id_fk
        foreign key (exercise_id) references exercises (exercise_id),
    constraint workoutplan_exercises_workoutplan_user_id_day_fk
        foreign key (user_id, day) references workoutplan (user_id, day)
);


