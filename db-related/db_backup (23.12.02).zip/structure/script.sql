CREATE TABLE activitylevels
(
    activitylevel_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    activitylevel    varchar(20) NOT NULL,
    description      varchar(70) NULL,
    CONSTRAINT activitylevels_pk
        UNIQUE (activitylevel)
);

CREATE TABLE daysperweek
(
    daysperweek int NOT NULL
        PRIMARY KEY
);

CREATE TABLE equipmentlevels
(
    equipmentlevel_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    equipmentlevel    varchar(30) NOT NULL,
    CONSTRAINT equipmentlevels_pk
        UNIQUE (equipmentlevel)
);

CREATE TABLE exercisenames
(
    name varchar(50) NOT NULL
        PRIMARY KEY
);

CREATE TABLE experiencelevels
(
    experiencelevel_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    experiencelevel    varchar(20) NOT NULL,
    CONSTRAINT experiencelevels_pk
        UNIQUE (experiencelevel)
);

CREATE TABLE genders
(
    gender varchar(2) NOT NULL
        PRIMARY KEY
);

CREATE TABLE intensitylevels
(
    intensitylevel_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    intensitylevel    varchar(20) NOT NULL,
    CONSTRAINT intensitylevel_id
        UNIQUE (intensitylevel_id),
    CONSTRAINT intensitylevels_pk2
        UNIQUE (intensitylevel)
);

CREATE TABLE musclegroups
(
    musclegroup varchar(10) NOT NULL
        PRIMARY KEY
);

CREATE TABLE overallgoals
(
    overgoal_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    overallgoal varchar(30) NULL,
    CONSTRAINT overallgoals_pk
        UNIQUE (overallgoal),
    CONSTRAINT overgoal_id
        UNIQUE (overgoal_id)
);

CREATE TABLE goals
(
    user_id           bigint UNSIGNED NOT NULL
        PRIMARY KEY,
    intensitylevel_id bigint UNSIGNED NULL,
    overallgoal_id    bigint UNSIGNED NULL,
    daysperweek       int             NULL,
    CONSTRAINT goals_intensitylevels_intensitylevel_id_fk
        FOREIGN KEY (intensitylevel_id) REFERENCES intensitylevels (intensitylevel_id),
    CONSTRAINT goals_overallgoals_overgoal_id_fk
        FOREIGN KEY (overallgoal_id) REFERENCES overallgoals (overgoal_id)
);

CREATE INDEX goals_daysperweek_daysperweek_fk
    ON goals (daysperweek);

CREATE TABLE roles
(
    role_id bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    role    varchar(10) NULL,
    CONSTRAINT role_id
        UNIQUE (role_id),
    CONSTRAINT roles_pk2
        UNIQUE (role)
);

CREATE TABLE settypes
(
    settype varchar(10) NOT NULL
        PRIMARY KEY
);

CREATE TABLE exercises
(
    exercise_id       bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    equipmentlevel_id bigint UNSIGNED NULL,
    musclegroup       varchar(10)     NULL,
    name              varchar(50)     NULL,
    settype           varchar(10)     NULL,
    targetmuscles     varchar(120)    NULL,
    videourl          varchar(200)    NULL,
    CONSTRAINT exercises_equipmentlevels_equipmentlevel_id_fk
        FOREIGN KEY (equipmentlevel_id) REFERENCES equipmentlevels (equipmentlevel_id),
    CONSTRAINT exercises_exercisenames_name_fk
        FOREIGN KEY (name) REFERENCES exercisenames (name),
    CONSTRAINT exercises_musclegroups_musclegroup_fk
        FOREIGN KEY (musclegroup) REFERENCES musclegroups (musclegroup),
    CONSTRAINT exercises_settypes_settype_fk
        FOREIGN KEY (settype) REFERENCES settypes (settype)
);

CREATE TABLE users
(
    user_id            bigint UNSIGNED AUTO_INCREMENT
        PRIMARY KEY,
    username           varchar(60)     NULL,
    emailaddress       varchar(100)    NULL,
    password_hash      varchar(100)    NULL,
    firstname          varchar(60)     NULL,
    lastname           varchar(60)     NULL,
    age                int             NULL,
    weight             int             NULL,
    height             int             NULL,
    gender             varchar(2)      NULL,
    activitylevel_id   bigint UNSIGNED NULL,
    experiencelevel_id bigint UNSIGNED NULL,
    equipmentlevel_id  bigint UNSIGNED NULL,
    role_id            bigint UNSIGNED NULL,
    darkmode           tinyint         NULL,
    CONSTRAINT users_pk
        UNIQUE (username),
    CONSTRAINT users_pk2
        UNIQUE (emailaddress),
    CONSTRAINT users_activitylevels_activitylevel_id_fk
        FOREIGN KEY (activitylevel_id) REFERENCES activitylevels (activitylevel_id),
    CONSTRAINT users_equipmentlevels_equipmentlevel_id_fk
        FOREIGN KEY (equipmentlevel_id) REFERENCES equipmentlevels (equipmentlevel_id),
    CONSTRAINT users_experiencelevels_experiencelevel_id_fk
        FOREIGN KEY (experiencelevel_id) REFERENCES experiencelevels (experiencelevel_id),
    CONSTRAINT users_genders_gender_fk
        FOREIGN KEY (gender) REFERENCES genders (gender),
    CONSTRAINT users_roles_role_id_fk
        FOREIGN KEY (role_id) REFERENCES roles (role_id)
);

CREATE TABLE users_exercises
(
    user_id        bigint UNSIGNED NOT NULL,
    exercise_id    bigint UNSIGNED NOT NULL,
    personalrecord int DEFAULT 0   NULL,
    rating         int DEFAULT 1   NULL,
    PRIMARY KEY (user_id, exercise_id),
    CONSTRAINT users_exercises_users_user_id_fk
        FOREIGN KEY (user_id) REFERENCES users (user_id)
);

CREATE TABLE workoutplan
(
    user_id bigint UNSIGNED NOT NULL,
    day     date            NOT NULL,
    PRIMARY KEY (user_id, day),
    CONSTRAINT workoutplan_users_user_id_fk
        FOREIGN KEY (user_id) REFERENCES users (user_id)
);

CREATE TABLE dailyworkouts_exercises
(
    user_id     bigint UNSIGNED         NOT NULL,
    day         date                    NOT NULL,
    exercise_id bigint UNSIGNED         NOT NULL,
    sets        int         DEFAULT 0   NULL,
    reps        varchar(20) DEFAULT '0' NULL,
    rest        varchar(20) DEFAULT '0' NULL,
    weight      int         DEFAULT 0   NULL,
    PRIMARY KEY (user_id, day, exercise_id),
    CONSTRAINT workoutplan_exercises2_exercises_exercise_id_fk
        FOREIGN KEY (exercise_id) REFERENCES exercises (exercise_id),
    CONSTRAINT workoutplan_exercises2_workoutplan_user_id_day_fk
        FOREIGN KEY (user_id, day) REFERENCES workoutplan (user_id, day)
);

CREATE INDEX workoutplan_exercises2_exercises_exercise_id_fk2
    ON dailyworkouts_exercises (exercise_id);

CREATE TABLE workoutplan_exercises
(
    user_id     bigint UNSIGNED         NOT NULL,
    day         date                    NOT NULL,
    exercise_id bigint UNSIGNED         NOT NULL,
    sets        int         DEFAULT 0   NOT NULL,
    reps        varchar(20) DEFAULT '0' NOT NULL,
    rest        varchar(20) DEFAULT '0' NOT NULL,
    weight      int         DEFAULT 0   NOT NULL,
    rpe         int         DEFAULT 0   NOT NULL,
    PRIMARY KEY (user_id, day, exercise_id),
    CONSTRAINT workoutplan_exercises_exercises_exercise_id_fk
        FOREIGN KEY (exercise_id) REFERENCES exercises (exercise_id),
    CONSTRAINT workoutplan_exercises_workoutplan_user_id_day_fk
        FOREIGN KEY (user_id, day) REFERENCES workoutplan (user_id, day)
);


