INSERT INTO fitforge.genders (gender)
VALUES  ('F'),
        ('M'),
        ('NB');