INSERT INTO fitforge.settypes (settype)
VALUES  ('Double'),
        ('Single'),
        ('Timed');