INSERT INTO fitforge.roles (role_id, role)
VALUES  (1, 'Admin'),
        (2, 'Dev'),
        (3, 'User');