INSERT INTO fitforge.musclegroups (musclegroup)
VALUES  ('Abs'),
        ('Back'),
        ('Biceps'),
        ('Chest'),
        ('Legs'),
        ('Shoulders'),
        ('Triceps');