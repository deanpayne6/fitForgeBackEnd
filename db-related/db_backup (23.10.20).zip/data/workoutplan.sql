INSERT INTO fitforge.workoutplan (user_id, day)
VALUES  (5, '2023-10-16'),
        (5, '2023-10-17'),
        (5, '2023-10-18');