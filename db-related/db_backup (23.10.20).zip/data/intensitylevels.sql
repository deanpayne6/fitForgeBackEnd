INSERT INTO fitforge.intensitylevels (intensitylevel_id, intensitylevel)
VALUES  (3, 'Intense'),
        (1, 'Light'),
        (2, 'Moderate');