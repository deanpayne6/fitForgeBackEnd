INSERT INTO fitforge.experiencelevels (experiencelevel_id, experiencelevel)
VALUES  (1, 'Beginner'),
        (3, 'Expert'),
        (2, 'Intermediate');