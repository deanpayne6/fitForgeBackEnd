INSERT INTO fitforge.activitylevels (activitylevel_id, activitylevel, description)
VALUES  (1, 'Sedentary', 'Little to No Exercise'),
        (2, 'Lightly Active', 'Light Exercise or Sports 1-3 Days a Week'),
        (3, 'Moderately Active', 'Moderate Exercise or Sports 3-5 Days a Week'),
        (4, 'Very Active', 'Hard Exercise or Sports 6-7 Days a Week'),
        (5, 'Extremely Active', 'Very Strenuous Exercise, Physical Job, or Training Twice a Day');