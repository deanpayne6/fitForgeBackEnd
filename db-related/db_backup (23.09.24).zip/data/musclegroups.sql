INSERT INTO fitforge.musclegroups (musclegroup)
VALUES  ('Abs'),
        ('Back'),
        ('Bicep'),
        ('Chest'),
        ('Legs'),
        ('Shoulder'),
        ('Tricep');