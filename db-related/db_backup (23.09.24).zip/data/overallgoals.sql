INSERT INTO fitforge.overallgoals (overgoal_id, overallgoal)
VALUES  (2, 'Muscle Building (Hypertrophy)'),
        (3, 'Strength and Power'),
        (1, 'Weight Loss');