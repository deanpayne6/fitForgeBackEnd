INSERT INTO fitforge.users (user_id, username, emailaddress, password_hash, firstname, lastname, age, weight, height, gender, activitylevel_id, experiencelevel_id, equipmentlevel_id, role_id, darkmode)
VALUES  (1, 'alex', 'alex@gmail.com', 'thisisapasshash', 'alex', 'weber', 22, 0, 0, 'M', 1, 1, 1, 1, 0),
        (2, 'luis', 'lsosorio1299@gmail.com', 'thisisluispasshash', 'luis', 'sierra osorio', 22, 0, 0, 'F', 2, 2, 2, 1, 1),
        (3, 'marshall', 'marshall@gmail.com', '$2b$10$UX4EPfwc4dTYNQ.a0dRYAegMhpgFC4rMdYVynapBo/F063sx4EdaW', 'marshall', 'keopong', 22, 0, 0, 'NB', 2, 3, 2, 1, 1),
        (4, 'alex1', 'alex1@gmail.com', '$2b$10$5h8SgICBlHe8LnUen6I6wepD/Z51uG7fws1XrlOK6eNvPKyS1D3d2', 'alex1', 'weber1', 22, 0, 0, 'M', 4, 3, 1, 1, 0),
        (5, 'andrew', 'realemail@gmail.com', 'realpassword', 'andrew', 'de la rosa', 22, 0, 0, 'M', 3, 2, 3, 1, 1);