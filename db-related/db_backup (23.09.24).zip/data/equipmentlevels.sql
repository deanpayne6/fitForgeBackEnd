INSERT INTO fitforge.equipmentlevels (equipmentlevel_id, equipmentlevel)
VALUES  (3, 'Commercial Gym'),
        (2, 'Home Gym or Limited Equipment'),
        (1, 'No Gym');